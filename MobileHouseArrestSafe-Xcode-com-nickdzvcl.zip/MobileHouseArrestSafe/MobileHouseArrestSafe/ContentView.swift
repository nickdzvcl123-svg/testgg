import SwiftUI
import UniformTypeIdentifiers

struct FileItem: Identifiable, Hashable {
    let url: URL
    var id: URL { url }
    var name: String { url.lastPathComponent }
    var isDirectory: Bool { (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false }
}

@MainActor
final class FileStore: ObservableObject {
    @Published var items: [FileItem] = []
    @Published var errorMessage: String?
    let root: URL

    init() {
        let fm = FileManager.default
        let base = fm.urls(for: .documentDirectory, in: .userDomainMask).first!
        root = base
        refresh()
    }

    func refresh() {
        do {
            let urls = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsHiddenFiles])
            items = urls.sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }.map(FileItem.init)
        } catch { errorMessage = error.localizedDescription }
    }

    func createTextFile() {
        let url = root.appendingPathComponent("NewFile.txt")
        var candidate = url
        var i = 1
        while FileManager.default.fileExists(atPath: candidate.path) {
            candidate = root.appendingPathComponent("NewFile-\(i).txt"); i += 1
        }
        do { try Data("Created by MobileHouseArrest\n".utf8).write(to: candidate); refresh() }
        catch { errorMessage = error.localizedDescription }
    }

    func delete(_ item: FileItem) {
        do { try FileManager.default.removeItem(at: item.url); refresh() }
        catch { errorMessage = error.localizedDescription }
    }
}

struct ContentView: View {
    @StateObject private var store = FileStore()
    @State private var showImporter = false
    @State private var showExporter = false
    @State private var selected: FileItem?
    @State private var newText = ""
    @State private var showEditor = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 14) {
                        Image("AppIcon")
                            .resizable().scaledToFill().frame(width: 54, height: 54).clipShape(RoundedRectangle(cornerRadius: 13))
                        VStack(alignment: .leading, spacing: 3) {
                            Text("MobileHouseArrest").font(.headline)
                            Text("Quản lý tệp an toàn").font(.subheadline).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 5)
                }

                Section("Tệp của ứng dụng") {
                    if store.items.isEmpty { Text("Chưa có tệp").foregroundStyle(.secondary) }
                    ForEach(store.items) { item in
                        Button { open(item) } label: {
                            HStack {
                                Image(systemName: item.isDirectory ? "folder.fill" : "doc.fill")
                                Text(item.name).foregroundStyle(.primary)
                                Spacer()
                            }
                        }
                        .swipeActions {
                            Button(role: .destructive) { store.delete(item) } label: { Label("Xóa", systemImage: "trash") }
                        }
                    }
                }

                Section("Tệp trên iPhone") {
                    Button { showImporter = true } label: { Label("Chọn tệp từ ứng dụng Tệp", systemImage: "folder.badge.plus") }
                    Text("iOS chỉ cho phép ứng dụng truy cập dữ liệu bên ngoài sandbox khi người dùng chọn hoặc cấp quyền phù hợp.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Files")
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { store.createTextFile() } label: { Image(systemName: "plus") }
                    Button { store.refresh() } label: { Image(systemName: "arrow.clockwise") }
                }
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls): importFiles(urls)
                case .failure(let error): store.errorMessage = error.localizedDescription
                }
            }
            .sheet(isPresented: $showEditor) {
                NavigationStack {
                    TextEditor(text: $newText).padding()
                        .navigationTitle(selected?.name ?? "Tệp")
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) { Button("Đóng") { showEditor = false } }
                            ToolbarItem(placement: .confirmationAction) { Button("Lưu") { saveSelected(); showEditor = false } }
                        }
                }
            }
            .alert("Lỗi", isPresented: Binding(get: { store.errorMessage != nil }, set: { if !$0 { store.errorMessage = nil } })) {
                Button("OK") { store.errorMessage = nil }
            } message: { Text(store.errorMessage ?? "") }
        }
    }

    private func open(_ item: FileItem) {
        guard !item.isDirectory else { return }
        selected = item
        if let text = try? String(contentsOf: item.url, encoding: .utf8) { newText = text; showEditor = true }
    }

    private func saveSelected() {
        guard let url = selected?.url else { return }
        do { try newText.data(using: .utf8)?.write(to: url); store.refresh() }
        catch { store.errorMessage = error.localizedDescription }
    }

    private func importFiles(_ urls: [URL]) {
        for url in urls {
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            let destination = store.root.appendingPathComponent(url.lastPathComponent)
            do {
                if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
                try FileManager.default.copyItem(at: url, to: destination)
            } catch { store.errorMessage = error.localizedDescription }
        }
        store.refresh()
    }
}
